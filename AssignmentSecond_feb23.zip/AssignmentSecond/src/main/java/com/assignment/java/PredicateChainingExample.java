package com.assignment.java;
import java.util.function.*;

public class PredicateChainingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer> p1=number->number>=20;
		Predicate<Integer> p2=number->number<=20;
		
		boolean result=p1.or(p2).test(50);
		
		System.out.println(result);
	}

}
