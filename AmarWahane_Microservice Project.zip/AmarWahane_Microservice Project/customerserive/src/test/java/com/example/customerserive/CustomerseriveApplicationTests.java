package com.example.customerserive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerseriveApplicationTests {

	@Test
	void contextLoads() {
	}

}
